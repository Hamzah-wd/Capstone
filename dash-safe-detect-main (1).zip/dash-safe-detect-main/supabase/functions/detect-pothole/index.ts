import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { image } = await req.json();
    
    if (!image) {
      throw new Error("No image data provided");
    }

    const ROBOFLOW_API_KEY = Deno.env.get("ROBOFLOW_API_KEY");
    if (!ROBOFLOW_API_KEY) {
      throw new Error("ROBOFLOW_API_KEY is not configured");
    }

    // Call Roboflow inference API
    const response = await fetch(
      `https://detect.roboflow.com/pothole-jujbl/1?api_key=${ROBOFLOW_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: image,
      }
    );

    if (!response.ok) {
      throw new Error(`Roboflow API error: ${await response.text()}`);
    }

    const result = await response.json();

    return new Response(
      JSON.stringify(result),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Detection error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
