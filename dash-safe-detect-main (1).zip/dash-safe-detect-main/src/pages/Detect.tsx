import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Camera, Upload, MapPin, ArrowLeft } from "lucide-react";

interface Detection {
  x: number;
  y: number;
  width: number;
  height: number;
  confidence: number;
  class: string;
}

const Detect = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [capturing, setCapturing] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [detections, setDetections] = useState<Detection[]>([]);
  const [isDetecting, setIsDetecting] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null);
  const detectionIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session?.user) {
        navigate("/auth");
      } else {
        setUser(session.user);
      }
    });

    // Get user location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          toast({
            title: "Location access denied",
            description: "Please enable location access for better accuracy",
            variant: "destructive",
          });
        }
      );
    }
  }, [navigate, toast]);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
        audio: false,
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      
      setStream(mediaStream);
      setCapturing(true);
    } catch (error) {
      console.error("Error accessing camera:", error);
      toast({
        title: "Camera access denied",
        description: "Please allow camera access to detect potholes",
        variant: "destructive",
      });
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
      setCapturing(false);
      setIsDetecting(false);
      setDetections([]);
      if (detectionIntervalRef.current) {
        clearInterval(detectionIntervalRef.current);
        detectionIntervalRef.current = null;
      }
    }
  };

  const detectPotholes = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.drawImage(video, 0, 0);
    
    canvas.toBlob(async (blob) => {
      if (!blob) return;

      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = async () => {
        const base64data = reader.result as string;
        
        try {
          const { data, error } = await supabase.functions.invoke("detect-pothole", {
            body: { image: base64data },
          });

          if (error) throw error;

          if (data?.predictions) {
            setDetections(data.predictions);
            drawDetections(data.predictions);
          }
        } catch (error) {
          console.error("Detection error:", error);
        }
      };
    }, "image/jpeg", 0.8);
  };

  const drawDetections = (predictions: Detection[]) => {
    if (!overlayCanvasRef.current || !videoRef.current) return;

    const canvas = overlayCanvasRef.current;
    const video = videoRef.current;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    predictions.forEach((detection) => {
      const x = detection.x - detection.width / 2;
      const y = detection.y - detection.height / 2;

      ctx.strokeStyle = "#f59e0b";
      ctx.lineWidth = 3;
      ctx.strokeRect(x, y, detection.width, detection.height);

      ctx.fillStyle = "#f59e0b";
      ctx.fillRect(x, y - 25, detection.width, 25);

      ctx.fillStyle = "#000";
      ctx.font = "16px sans-serif";
      ctx.fillText(
        `${detection.class} ${(detection.confidence * 100).toFixed(0)}%`,
        x + 5,
        y - 7
      );
    });
  };

  const startDetection = () => {
    setIsDetecting(true);
    detectPotholes();
    detectionIntervalRef.current = setInterval(detectPotholes, 2000) as unknown as number;
  };

  const stopDetection = () => {
    setIsDetecting(false);
    setDetections([]);
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current);
      detectionIntervalRef.current = null;
    }
    if (overlayCanvasRef.current) {
      const ctx = overlayCanvasRef.current.getContext("2d");
      if (ctx) {
        ctx.clearRect(0, 0, overlayCanvasRef.current.width, overlayCanvasRef.current.height);
      }
    }
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        canvas.toBlob((blob) => {
          if (blob) {
            navigate("/report", { 
              state: { 
                imageBlob: blob,
                location 
              } 
            });
            stopCamera();
          }
        }, "image/jpeg");
      }
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      navigate("/report", { 
        state: { 
          imageBlob: file,
          location 
        } 
      });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Detect Potholes</h1>
            <p className="text-sm text-muted-foreground">
              {location ? "Location tracking active" : "Acquiring location..."}
            </p>
          </div>
        </div>

        <Card className="p-6 space-y-6">
          {!capturing ? (
            <div className="space-y-4">
              <div className="aspect-video bg-muted rounded-lg flex flex-col items-center justify-center gap-4 p-8 text-center">
                <Camera className="w-16 h-16 text-muted-foreground" />
                <div>
                  <p className="text-lg font-medium mb-2">Start Camera Detection</p>
                  <p className="text-sm text-muted-foreground">
                    Use your camera to capture road damage in real-time
                  </p>
                </div>
              </div>

              <Button 
                className="w-full" 
                size="lg"
                onClick={startCamera}
              >
                <Camera className="w-5 h-5 mr-2" />
                Start Camera
              </Button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">Or</span>
                </div>
              </div>

              <Button 
                variant="outline" 
                className="w-full" 
                size="lg"
                onClick={() => document.getElementById("file-upload")?.click()}
              >
                <Upload className="w-5 h-5 mr-2" />
                Upload Image
              </Button>
              <input
                id="file-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileUpload}
              />
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-cover"
                />
                <canvas 
                  ref={overlayCanvasRef}
                  className="absolute top-0 left-0 w-full h-full pointer-events-none"
                />
                <canvas ref={canvasRef} className="hidden" />
                
                {location && (
                  <div className="absolute top-4 left-4 bg-black/70 text-white px-3 py-2 rounded-lg flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm">Location tracked</span>
                  </div>
                )}

                {isDetecting && (
                  <div className="absolute top-4 right-4 bg-accent/90 text-black px-3 py-2 rounded-lg flex items-center gap-2">
                    <div className="w-2 h-2 bg-black rounded-full animate-pulse" />
                    <span className="text-sm font-medium">Detecting...</span>
                  </div>
                )}

                {detections.length > 0 && (
                  <div className="absolute bottom-4 left-4 bg-accent/90 text-black px-3 py-2 rounded-lg">
                    <span className="text-sm font-medium">
                      {detections.length} pothole{detections.length > 1 ? 's' : ''} detected
                    </span>
                  </div>
                )}
              </div>

              <div className="flex gap-4">
                {!isDetecting ? (
                  <Button 
                    className="flex-1"
                    onClick={startDetection}
                  >
                    Start Detection
                  </Button>
                ) : (
                  <Button 
                    variant="outline"
                    className="flex-1"
                    onClick={stopDetection}
                  >
                    Stop Detection
                  </Button>
                )}
              </div>

              <div className="flex gap-4">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={stopCamera}
                >
                  Cancel
                </Button>
                <Button 
                  className="flex-1"
                  onClick={captureImage}
                  disabled={isDetecting}
                >
                  <Camera className="w-5 h-5 mr-2" />
                  Capture
                </Button>
              </div>

              <p className="text-sm text-center text-muted-foreground">
                {isDetecting 
                  ? "AI is analyzing the camera feed for potholes" 
                  : "Start detection to identify potholes in real-time"}
              </p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};

export default Detect;