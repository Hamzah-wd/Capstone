import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Send } from "lucide-react";
import { z } from "zod";

const reportSchema = z.object({
  description: z.string().trim().min(10, "Description must be at least 10 characters").max(500),
  severity: z.enum(["low", "medium", "high", "critical"]),
});

const Report = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [imagePreview, setImagePreview] = useState<string>("");
  const [description, setDescription] = useState("");
  const [severity, setSeverity] = useState<string>("medium");
  const [locationAddress, setLocationAddress] = useState<string>("");

  const imageBlob = location.state?.imageBlob;
  const geoLocation = location.state?.location;

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session?.user) {
        navigate("/auth");
      } else {
        setUser(session.user);
      }
    });

    if (!imageBlob) {
      navigate("/detect");
    } else {
      const url = URL.createObjectURL(imageBlob);
      setImagePreview(url);
      return () => URL.revokeObjectURL(url);
    }
  }, [navigate, imageBlob]);

  useEffect(() => {
    if (geoLocation) {
      // Reverse geocoding would go here with Google Maps API
      setLocationAddress(`${geoLocation.latitude.toFixed(6)}, ${geoLocation.longitude.toFixed(6)}`);
    }
  }, [geoLocation]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      reportSchema.parse({ description, severity });

      if (!user) {
        toast({
          title: "Error",
          description: "You must be logged in to submit a report",
          variant: "destructive",
        });
        return;
      }

      // Upload image to storage
      const fileExt = imageBlob.type.split("/")[1];
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;
      const { error: uploadError, data: uploadData } = await supabase.storage
        .from("pothole-images")
        .upload(fileName, imageBlob);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from("pothole-images")
        .getPublicUrl(fileName);

      // Create report
      const { error: reportError } = await supabase
        .from("pothole_reports")
        .insert({
          user_id: user.id,
          image_url: publicUrl,
          latitude: geoLocation?.latitude,
          longitude: geoLocation?.longitude,
          location_address: locationAddress,
          description,
          severity,
        });

      if (reportError) throw reportError;

      toast({
        title: "Report submitted!",
        description: "Thank you for helping improve road safety",
      });

      navigate("/reports");
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Validation error",
          description: error.errors[0].message,
          variant: "destructive",
        });
      } else {
        console.error("Error submitting report:", error);
        toast({
          title: "Error",
          description: "Failed to submit report. Please try again.",
          variant: "destructive",
        });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate("/detect")}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold">Submit Report</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card className="p-6 space-y-6">
            {imagePreview && (
              <div className="space-y-2">
                <Label>Captured Image</Label>
                <img
                  src={imagePreview}
                  alt="Pothole"
                  className="w-full rounded-lg border border-border"
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={locationAddress}
                onChange={(e) => setLocationAddress(e.target.value)}
                placeholder="Location will be detected automatically"
                disabled={!!geoLocation}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="severity">Severity Level</Label>
              <Select value={severity} onValueChange={setSeverity}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low - Minor surface damage</SelectItem>
                  <SelectItem value="medium">Medium - Noticeable pothole</SelectItem>
                  <SelectItem value="high">High - Large pothole</SelectItem>
                  <SelectItem value="critical">Critical - Dangerous road damage</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Provide additional details about the road damage..."
                rows={4}
                maxLength={500}
                required
              />
              <p className="text-xs text-muted-foreground">
                {description.length}/500 characters
              </p>
            </div>
          </Card>

          <Button type="submit" className="w-full" size="lg" disabled={loading}>
            <Send className="w-5 h-5 mr-2" />
            {loading ? "Submitting..." : "Submit Report"}
          </Button>
        </form>
      </div>
    </div>
  );
};

export default Report;