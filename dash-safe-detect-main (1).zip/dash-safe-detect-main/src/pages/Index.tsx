import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { MapPin, Camera, FileText, AlertTriangle } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setUser(session?.user ?? null);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-accent/5">
        <div className="container mx-auto px-4 py-20 md:py-32">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full">
              <AlertTriangle className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Community-Powered Road Safety</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight">
              Report Road Issues
              <span className="block text-primary mt-2">Make Roads Safer</span>
            </h1>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Use your phone's camera to detect and report potholes instantly. 
              Help your community maintain safer roads for everyone.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              {user ? (
                <>
                  <Button 
                    size="lg" 
                    onClick={() => navigate("/detect")}
                    className="text-lg px-8"
                  >
                    <Camera className="w-5 h-5 mr-2" />
                    Start Detecting
                  </Button>
                  <Button 
                    size="lg" 
                    variant="outline"
                    onClick={() => navigate("/map")}
                    className="text-lg px-8"
                  >
                    <MapPin className="w-5 h-5 mr-2" />
                    View Map
                  </Button>
                </>
              ) : (
                <>
                  <Button 
                    size="lg" 
                    onClick={() => navigate("/auth")}
                    className="text-lg px-8"
                  >
                    Get Started
                  </Button>
                  <Button 
                    size="lg" 
                    variant="outline"
                    onClick={() => navigate("/map")}
                    className="text-lg px-8"
                  >
                    <MapPin className="w-5 h-5 mr-2" />
                    View Public Map
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            How It Works
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center space-y-4 p-6 rounded-lg bg-background border border-border">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <Camera className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Detect Potholes</h3>
              <p className="text-muted-foreground">
                Use your camera to capture road damage in real-time with AI detection
              </p>
            </div>
            
            <div className="text-center space-y-4 p-6 rounded-lg bg-background border border-border">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto">
                <MapPin className="w-8 h-8 text-accent" />
              </div>
              <h3 className="text-xl font-semibold">Automatic Location</h3>
              <p className="text-muted-foreground">
                GPS automatically tags the exact location of each pothole
              </p>
            </div>
            
            <div className="text-center space-y-4 p-6 rounded-lg bg-background border border-border">
              <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto">
                <FileText className="w-8 h-8 text-success" />
              </div>
              <h3 className="text-xl font-semibold">Track Progress</h3>
              <p className="text-muted-foreground">
                Submit reports and track repairs through our support system
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      {!user && (
        <section className="py-20 bg-gradient-to-r from-primary to-primary/80">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-6">
              Ready to Make a Difference?
            </h2>
            <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
              Join thousands of citizens reporting road issues and helping maintain safer streets
            </p>
            <Button 
              size="lg" 
              variant="secondary"
              onClick={() => navigate("/auth")}
              className="text-lg px-8"
            >
              Sign Up Now
            </Button>
          </div>
        </section>
      )}

      {/* Navigation Footer */}
      {user && (
        <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex justify-around py-4">
              <Button variant="ghost" onClick={() => navigate("/detect")}>
                <Camera className="w-5 h-5" />
              </Button>
              <Button variant="ghost" onClick={() => navigate("/map")}>
                <MapPin className="w-5 h-5" />
              </Button>
              <Button variant="ghost" onClick={() => navigate("/reports")}>
                <FileText className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </nav>
      )}
    </div>
  );
};

export default Index;