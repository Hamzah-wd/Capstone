import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, MapPin, Navigation } from "lucide-react";
import { APIProvider, Map as GoogleMap, AdvancedMarker, InfoWindow } from '@vis.gl/react-google-maps';

interface PotholeReport {
  id: string;
  latitude: number;
  longitude: number;
  location_address: string;
  description: string;
  severity: string;
  status: string;
  created_at: string;
  image_url?: string;
}

const Map = () => {
  const navigate = useNavigate();
  const [reports, setReports] = useState<PotholeReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [selectedReport, setSelectedReport] = useState<string | null>(null);
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "";

  useEffect(() => {
    fetchReports();
    getUserLocation();
  }, []);

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          // Default to a central location if geolocation fails
          setUserLocation({ lat: 0, lng: 0 });
        }
      );
    }
  };

  const fetchReports = async () => {
    try {
      const { data, error } = await supabase
        .from("pothole_reports")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setReports(data || []);
    } catch (error) {
      console.error("Error fetching reports:", error);
    } finally {
      setLoading(false);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "low": return "bg-success";
      case "medium": return "bg-warning";
      case "high": return "bg-accent";
      case "critical": return "bg-destructive";
      default: return "bg-muted";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "default";
      case "in_progress": return "secondary";
      case "resolved": return "outline";
      default: return "default";
    }
  };

  const mapCenter = userLocation || { lat: 0, lng: 0 };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold">Pothole Map</h1>
            <p className="text-sm text-muted-foreground">
              {reports.length} report{reports.length !== 1 ? 's' : ''} found
            </p>
          </div>
        </div>

        {loading || !userLocation ? (
          <Card className="p-12 text-center">
            <div className="animate-pulse">
              <Navigation className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Loading map...</p>
            </div>
          </Card>
        ) : (
          <div className="space-y-4">
            <Card className="p-0 overflow-hidden">
              <APIProvider apiKey={apiKey}>
                <div className="w-full h-[60vh] md:h-[70vh]">
                  <GoogleMap
                    defaultCenter={mapCenter}
                    defaultZoom={13}
                    mapId="pothole-map"
                    gestureHandling="greedy"
                    disableDefaultUI={false}
                    clickableIcons={false}
                  >
                    {/* User location marker */}
                    {userLocation && (
                      <AdvancedMarker
                        position={userLocation}
                        title="Your Location"
                      >
                        <div className="relative">
                          <div className="absolute -top-8 -left-4 bg-primary text-primary-foreground rounded-full p-2 shadow-lg border-2 border-background">
                            <Navigation className="w-4 h-4" />
                          </div>
                          <div className="absolute -top-2 -left-2 w-4 h-4 bg-primary/30 rounded-full animate-ping" />
                        </div>
                      </AdvancedMarker>
                    )}

                    {/* Pothole markers */}
                    {reports.map((report) => (
                      <AdvancedMarker
                        key={report.id}
                        position={{ lat: report.latitude, lng: report.longitude }}
                        onClick={() => setSelectedReport(report.id)}
                      >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shadow-lg border-2 border-background cursor-pointer hover:scale-110 transition-transform ${getSeverityColor(report.severity)}`}>
                          <MapPin className="w-4 h-4 text-white" />
                        </div>
                      </AdvancedMarker>
                    ))}

                    {/* Info windows */}
                    {reports.map((report) => (
                      selectedReport === report.id && (
                        <InfoWindow
                          key={`info-${report.id}`}
                          position={{ lat: report.latitude, lng: report.longitude }}
                          onCloseClick={() => setSelectedReport(null)}
                        >
                          <div className="p-2 max-w-xs">
                            <div className="flex items-start gap-2 mb-2">
                              <Badge variant={getStatusColor(report.status)} className="text-xs">
                                {report.status.replace("_", " ")}
                              </Badge>
                              <Badge variant="outline" className="text-xs capitalize">
                                {report.severity}
                              </Badge>
                            </div>
                            <p className="font-medium text-sm mb-1">{report.location_address}</p>
                            <p className="text-xs text-muted-foreground mb-2">{report.description}</p>
                            <p className="text-xs text-muted-foreground">
                              Reported: {new Date(report.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </InfoWindow>
                      )
                    ))}
                  </GoogleMap>
                </div>
              </APIProvider>
            </Card>

            {reports.length === 0 && (
              <Card className="p-12 text-center">
                <MapPin className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Reports Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Be the first to report a pothole in your area
                </p>
                <Button onClick={() => navigate("/detect")}>
                  Start Detecting
                </Button>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Map;